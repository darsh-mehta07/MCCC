import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-splash1',
  templateUrl: './splash1.component.html',
  styleUrls: ['./splash1.component.css']
})
export class Splash1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
