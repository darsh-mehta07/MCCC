export class Register {
    id: number | undefined;
    name: string | undefined;
    password: string | undefined;
    email: string | undefined;
    phone: string | undefined;
    dob: string | undefined;
    confirm_password: string | undefined;
    select_state: string | undefined;
    select_city: string | undefined;
    gender: string | undefined;
}
