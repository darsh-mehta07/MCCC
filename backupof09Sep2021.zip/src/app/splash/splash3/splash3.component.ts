import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-splash3',
  templateUrl: './splash3.component.html',
  styleUrls: ['./splash3.component.css']
})
export class Splash3Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
